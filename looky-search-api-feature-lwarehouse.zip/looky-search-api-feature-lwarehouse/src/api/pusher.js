// const Pusher = require("pusher");

// const pusher = new Pusher({
//     appId: "1593298",
//     key: "304e555bfb4afa2ba2d7",
//     secret: "9871a981a4d83d5fa04e",
//     cluster: "ap1",
//     useTLS: true
//   });
  
//   pusher.trigger("cebuChannel", "online", {
//     message: "hello world",
//     currentLocation:[{long:321,lat:3231}]
//   });
  
//   pusher.trigger

